#include <iostream>
#include "histogramdist.h"

using namespace std;
using namespace eosim::dist;

const int cant_muestras = 200;

int main()
{
    //Creo el array para guardar las distribuciones; la de la figura 4.3 del libro
    //y el que guarda el resultado
    double* de_histogram = new double[8];//{0.05, 0.5, 0.67, 0.82, 0.9, 0.94, 0.97, 1.0};
    de_histogram[0] = 0.05; de_histogram[1] = 0.5; de_histogram[2] = 0.67; de_histogram[3] = 0.82;
    de_histogram[4] = 0.9; de_histogram[5] = 0.94; de_histogram[6] = 0.97; de_histogram[7] = 1.0;

    HistogramDist* hd_discreta = new HistogramDist(MT19937, true, de_histogram, 8);
    HistogramDist* hd_continua = new HistogramDist(MT19937, false, de_histogram, 8);

    cout << "Muestra Discreta : Distribucion Continua" << endl;
    for (int i = 0 ; i < cant_muestras ; i++)
    {
        cout << "Muestra (Discreta) --> " << hd_discreta->sample();
        cout << " Muestra (Continua) --> " << hd_continua->sample() << endl;
    }

    return 0;
}
