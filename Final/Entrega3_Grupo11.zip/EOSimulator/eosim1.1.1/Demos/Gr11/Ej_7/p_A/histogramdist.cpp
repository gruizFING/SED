#include "histogramdist.h"

HistogramDist::HistogramDist(eosim::dist::GenType gen, bool disc, double* dist, int cant) : Distribution(gen), discreta(disc)
{
    cant_muestras = cant;
    distribucion = new double[cant_muestras];
    for (int i = 0; i < cant ; i++)
        distribucion[i] = dist[i];
}

HistogramDist::~HistogramDist()
{
    delete [] distribucion;
}


double HistogramDist::sample()
{
    if (discreta)
        return muestreoDiscreto();
    else
        return muestreoContinuo();
}


int HistogramDist::muestreoDiscreto()
{
    unsigned int x = 1;
    double rnd = generator->nextDouble();
    while (rnd > distribucion[x-1])
        x++;
    return x;
}

double HistogramDist::muestreoContinuo()
{
    unsigned int x = 1;
    double rnd = generator->nextDouble();
    while (rnd > distribucion[x-1])
        x++;
    double aux = x == 1 ? 0 : distribucion[x-2];
    return x + (rnd - aux)/(distribucion[x-1] - aux);
}
