#ifndef HISTOGRAMDIST_H
#define HISTOGRAMDIST_H

#include <eosim/dist/distribution.hpp>

class HistogramDist : public eosim::dist::Distribution
{
    private:
        bool discreta;
        double* distribucion;
        int cant_muestras;

        int muestreoDiscreto();
        double muestreoContinuo();

    public:
        HistogramDist(eosim::dist::GenType gen, bool discret, double* dist, int cant);
        virtual ~HistogramDist();

        /**
		* This operation samples a value from the distribution.
		*/
		double sample ();

};

#endif // HISTOGRAMDIST_H
