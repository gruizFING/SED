#ifndef UTILS_H
#define UTILS_H


class Utils
{
    public:
        Utils();
        virtual ~Utils();
    protected:
    private:
};

#endif // UTILS_H
