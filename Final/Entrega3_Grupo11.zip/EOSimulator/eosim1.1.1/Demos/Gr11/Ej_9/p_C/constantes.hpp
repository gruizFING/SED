#ifndef CONSTANTES_HPP_
#define CONSTANTES_HPP_

// constantes del modelo del hospital simple
const unsigned int cantCamas = 20;
const double tasaArribos = 6;
const double mediaEstadia = 120;
const double desviacionEstadia = 20;
const double timeIntervalCMAM = 5;

#endif
