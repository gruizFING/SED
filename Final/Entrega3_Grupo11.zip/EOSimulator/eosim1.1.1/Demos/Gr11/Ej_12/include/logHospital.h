#ifndef LOGHOSPITAL_H
#define LOGHOSPITAL_H


class logHospital
{
    public:
        logHospital();
        virtual ~logHospital();
    protected:
    private:
};

#endif // LOGHOSPITAL_H
