Read Me

In this zip file you will find:
* source code of EOSimulator;
* 2 Examples (repair shop, simple hospital from O�Keefe, R [1989] �Simulation modeling with Pascal� ISBN 0-13-811571-0)
* documentation of the package

To compile the library there are Devcpp Proyects and Visual Studio 2005 Proyects for the library and examples, and a Makefile for EOSimulator but not for the examples.
To use the proyects, just open them and compile them. They will compile within the directory tree structure contained in the zip file.
For the MakeFile you have to set the includes of your C++ compiler under CXXINCS and INCS.

Have Fun!