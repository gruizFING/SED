#include <eosim/graphic/graphicentity.hpp>
//
//using namespace eosim::graphic;
//
//		simpp::sprite sp;
//	public:
//		GraphicEntity(GraphicModel &gm, const char* imageFile, double x, double y) : sp(;
//		~GraphicEntity();
//	};
